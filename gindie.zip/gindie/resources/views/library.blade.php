@php
$biblioteca = session('biblioteca', []);
@endphp

<section class="mt-5">
    <h1>Mi Biblioteca:</h1>
    @foreach($biblioteca as $juegoId)
        @php
        $juego = App\Models\Juego::find($juegoId);
        @endphp

        <div class="card" style="width: 18rem;">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">{{ $juego->name }}</h5>
                <p class="card-text">{{ $juego->categoria }}</p>
                <p class="card-text">{{ $juego->plataforma }}</p>
                <p class="card-text">{{ $juego->tamanio }} GB</p>
            </div>
        </div>
    @endforeach
</section>
