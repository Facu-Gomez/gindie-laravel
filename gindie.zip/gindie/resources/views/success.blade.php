@extends('layout')
<div class="mt">
        <h1 id="exitoso" class="text-center">Su carga ha sido exitosa!</h1>
        <h2 id="volver" class="text-center"><a href="/">Volver al inicio</a></h2>
    </div>