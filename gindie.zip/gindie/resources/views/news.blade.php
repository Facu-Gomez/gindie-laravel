@extends('layout')

<section class="mt-5">
<div class="card text-center">
  <div class="card-header">
    Novedades!
  </div>
  @foreach($news as $new)
  <div class="card-body">
    <h5 class="card-title">{{$new->title}}</h5>
    
    <p class="card-text">{{$new->description}}</p>
  </div>
  <div class="card-footer text-body-secondary">
    {{$new->created_at}}
  </div>
  <hr>
  @endforeach
  
</div>

</section>