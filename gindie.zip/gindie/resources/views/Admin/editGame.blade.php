@extends('layout')

@section('content')

<form action="{{ route('games.update', $game) }}" method="post" class="mt" enctype="multipart/form-data">
    @csrf
    @method($method)     

    <div id="name">
        <label for="name">Nombre</label>
        <input type="text" name="name" value="{{ $game->name }}">
    
    </div>
    <div id="categoriasDiv">
    <label for="categories">Categorias</label>
    <select name="category_id" id="categories">
    @foreach($categories as $category)
    <option value="{{$category->id}}">{{$category->name}}</option>
  @endforeach
    </select>
    </div>

    <div id="plataform">
        <label for="plataform">Plataforma</label>
        <input type="text" name="plataform" value="{{ $game->plataform }}">
    </div>

    <div id="size">
        <label for="size">Tamaño</label>
        <input type="number" name="size" value="{{ $game->size }}">
    </div>

    <div>
        <label for="image">Foto</label>
        <input type="file" name="image" accept="image/jpg,image/jpeg,image/png">
    </div>
    <button>Actualizar Juego</button>
</form>
