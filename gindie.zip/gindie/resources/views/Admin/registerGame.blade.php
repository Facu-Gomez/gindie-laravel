@extends('layout')

@section('content')
<form action="{{ route('games.store') }}" method="post" class="mt" enctype="multipart/form-data">
    @csrf
    @method($method)     

    <div id="name">
        <label for="name">Nombre</label>
        <input type="text" name="name" value="">
    
    </div>
    <div id="categoriasDiv">
    <label for="categories">Categorias</label>
    <select name="category_id" id="categories">
    @foreach($categories as $category)
    <option value="{{$category->id}}">{{$category->name}}</option>
  @endforeach
    </select>
    </div>

    <div id="plataform">
        <label for="plataform">Plataforma</label>
        <input type="text" name="plataform">
    </div>

    <div id="size">
        <label for="size">Tamaño</label>
        <input type="number" name="size">
    </div>

    <div>
        <label for="imagen">Foto</label>
        <input type="file" name="imagen" accept="image/jpg,image/jpeg,image/png">
    </div>
    <button>Cargar Juego</button>
</form>
