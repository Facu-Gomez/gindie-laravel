@extends('layout')

@section('content')
    <section class="mt-5">
        <h1>Lista de Usuarios:</h1>
        <div class="row row-cols-1 row-cols-md-4 g-4 mx-auto">
            @foreach($users as $user)
                <div class="col">
                    <div class="card" style="width: 18rem;">

                        <div class="card-body">
                            <h5 class="card-title">Nombre: {{ $user->name }}</h5>
                            <p class="card-text">Mail: {{ $user->email }}</p>
                            <p class="card-text">Rol: {{ $user->role }}</p>

                        </form>
                   
                        </div>
                    </div>
                    
                </div>
            @endforeach
        </div>
    </section>
@endsection
