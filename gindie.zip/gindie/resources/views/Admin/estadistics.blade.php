@extends('layout')

@section('content')
<section>
    <h1 class="mt-5 text-center">Estadísticas</h1>
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fa-solid fa-gamepad" style="color: #8536ba; font-size: 2rem;"></i>
                        <h5 class="card-title mt-3">Cantidad de Juegos</h5>
                        <p class="card-text">{{ $gamesCount }}</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fa-solid fa-newspaper" style="color: #8536ba; font-size: 2rem;"></i>
                        <h5 class="card-title mt-3">Cantidad de Noticias</h5>
                        <p class="card-text">{{ $newsCount }}</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fa-solid fa-user" style="color: #8536ba; font-size: 2rem;"></i>
                        <h5 class="card-title mt-3">Cantidad de Usuarios</h5>
                        <p class="card-text">{{ $usersCount }}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
