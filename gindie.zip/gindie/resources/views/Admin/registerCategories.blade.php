@extends('layout')

@section('content')

<form action="{{ route('categories.store') }}" method="post" class="mt" enctype="multipart/form-data">
    @csrf

    <div id="name">
        <label for="name">Nombre</label>
        <input type="text" name="name" value="">
    </div>

    <button>Cargar Categoria</button>
</form>