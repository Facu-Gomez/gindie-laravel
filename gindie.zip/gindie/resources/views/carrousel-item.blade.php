<div class="carousel-item {{ $isActive ? 'active' : '' }}"
 style="background-image: url({{ $url }})">
</div>