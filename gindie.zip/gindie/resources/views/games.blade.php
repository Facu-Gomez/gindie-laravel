@extends('layout')

@section('content')
    <section class="mt-5">
        <h1>Lista de juegos:</h1>
        <div class="row row-cols-1 row-cols-md-4 g-4 mx-auto">
            @foreach($games as $game)
                <div class="col">
                    <div class="card" style="width: 18rem;">
                        <img src="{{ Storage::url('app' . $game->imagen) }}" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">{{ $game->name }}</h5>
                            <p class="card-text">{{ $game->category->name}}</p>
                            <p class="card-text">{{ $game->plataform }}</p>
                            <p class="card-text">{{ $game->size }} GB</p>
                           
                            <form action="{{ route('library.store', $game->id) }}" method="post">
                            @csrf
                             <input type="hidden" name="game_id" value="{{ $game->id }}">
                                <button type="submit" class="btn btn-outline-dark">📥</button>
                                
                            </form>
                            
                            @if(Auth::check() && Auth::user()->role === 'admin')
                            <a href="{{ route('games.edit', $game->id) }}" class="btn btn-outline-dark">✏</a>
                            <a href="{{ route('games.destroy', $game->id) }}" class="btn btn-outline-dark">❌</a>
                            
                        </form>
                            @endif
                        </div>
                    </div>
                    
                </div>
            @endforeach
        </div>
    </section>
@endsection
