@extends('layout')
   
   
   @section('content')

  <!-- ======= Hero Section ======= -->
     
    @include('carrusel')
    
  <!-- End Hero -->

  <main id="main">

    <!-- ======= My & Family Section ======= -->
    
    @include('gindie')
    
    <!-- End My & Family Section -->

    <!-- ======= Features Section ======= -->
    <!-- End Features Section -->
    
    <!-- End Recent Photos Section -->

  </main><!-- End #main -->
@endsection
