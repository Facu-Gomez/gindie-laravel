@extends('layout')

@section('content')

@if($errors->any())
     <ul>
          @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
           @endforeach     
     </ul>
@endif

<form action="/login" method="post" class="mt">
    @csrf
     
    <div id="email">
         <label for="email">Mail</label>
         <input type="email"  name="email">
     </br>
         @error('email') {{ $message }} @enderror        
    </div>

    <div id="password">
         <label for="password">Contraseña</label>
         <input type="password"  name="password">
     </br>

         @error('password') {{ $message }} @enderror 
    </div>

    <button>Continuar</button>

</form>