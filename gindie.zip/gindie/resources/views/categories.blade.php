@extends('layout')

<section class="mt-5">
<div class="card text-center">
  <div class="card-header">
    Categorias
  </div>
  @foreach($categories as $category)
  <div class="card-body">
    <h5 class="card-title">{{$category->name}}</h5>
    
  </div>
  <div class="card-footer text-body-secondary">
    {{$category->created_at}}
  </div>
  <hr>
  @endforeach
  
</div>

</section>