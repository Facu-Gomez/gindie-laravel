@php
$slides = [
    'img/carrusel/shovel.jpg',
    'img/carrusel/stardew.png',
    'img/carrusel/meat.jpg',
]
@endphp

<section id="hero">
    <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel" data-bs-interval="3000"> 


        <div class="carousel-inner" role="listbox">

            @foreach($slides as $slide)
            if($loop->first)
            @include('carrousel-item', [
              'isActive' => $loop->first,
              'url' => $slide
              ])
            @endforeach

        </div>

    </div>
</section>
