<footer id="footer">
  <div class="container">
    <h3>GINDIE</h3>
    <p>Descubre el emocionante mundo de los juegos indie en GINDIE. Sumérgete en experiencias únicas y creativas que desafían los límites de la imaginación.</p>
    <div class="social-links">
      <a href="#" class="twitter"><i class="fab fa-twitter"></i></a>
      <a href="#" class="facebook"><i class="fab fa-facebook"></i></a>
      <a href="#" class="instagram"><i class="fab fa-instagram"></i></a>
      <a href="#" class="google-plus"><i class="fab fa-google-plus"></i></a>
      <a href="#" class="linkedin"><i class="fab fa-linkedin"></i></a>
      <a href="#" class="youtube"><i class="fab fa-youtube"></i></a>
    </div>
    <div class="copyright">
      &copy; Derechos de autor <strong><span>GINDIE</span></strong>. Todos los derechos reservados.
    </div>
    <div class="credits">
      Diseñado por <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </div>
</footer>
