@extends('layout')

@section('content')
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-body text-center"> <!-- Alineado al centro -->
                        <h1 class="card-title mb-4">Perfil de Usuario</h1>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">
                                <strong>Nombre:</strong> {{ $user->name }}
                            </li>
                            <li class="list-group-item">
                                <strong>Email:</strong> {{ $user->email }}
                            </li>
                        </ul>
                        <a href="{{ route('admin.user.edit', ['user' => $user->id]) }}" class="btn btn-light mt-4"><i class="fa-solid fa-pencil" style="color: #8536ba; font-size: 1rem;"></i> Editar Perfil</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
