
<header id="header" class="fixed-top">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="/">GINDIE</a></h1>

      <nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="/">Home</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link " href="/juegos">Juegos</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " href="/novedades">Novedades</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/categorias">Categorias</a>
        </li>
        <?php if(Auth::check()): ?>
        <li class="nav-item">
          <a class="nav-link" href="/library">Biblioteca</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/login">Cerrar sesion</a>
        </li>
        <?php endif; ?>
        <?php if(Auth::check() && Auth::user()->role === 'admin'): ?>
        <li class="nav-item">
            <a class="nav-link" href="/cargarJuego">Cargar Juego</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/cargarNovedades">Cargar Novedad</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/cargarCategorias">Cargar Categorias</a>
        </li>
        <?php endif; ?>

        <?php if (! (Auth::check())): ?>
        <li class="nav-item">
          <a class="nav-link" href="/login">Iniciar sesion</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/register">Registrarse</a>
        </li>
      <?php endif; ?>
     
      </ul>

    </div>
  </div>
</nav>

    </div>
  </header>
<?php /**PATH C:\Users\Facum\Desktop\gindie\resources\views/navegacion.blade.php ENDPATH**/ ?>