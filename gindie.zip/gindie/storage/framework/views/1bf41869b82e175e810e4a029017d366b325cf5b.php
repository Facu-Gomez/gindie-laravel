

<?php $__env->startSection('content'); ?>
    <section class="mt-5">
        <h1>Lista de juegos:</h1>
        <div class="row row-cols-1 row-cols-md-4 g-4 mx-auto">
            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card" style="width: 18rem;">
                        <img src="<?php echo e(Storage::url('app' . $game->imagen)); ?>" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($game->name); ?></h5>
                            <p class="card-text"><?php echo e($game->category->name); ?></p>
                            <p class="card-text"><?php echo e($game->plataform); ?></p>
                            <p class="card-text"><?php echo e($game->size); ?> GB</p>
                           
                            <form action="<?php echo e(route('library.store', $game->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                             <input type="hidden" name="game_id" value="<?php echo e($game->id); ?>">
                                <button type="submit" class="btn btn-outline-dark">📥</button>
                                
                            </form>
                            
                            <?php if(Auth::check() && Auth::user()->role === 'admin'): ?>
                            <a href="<?php echo e(route('games.edit', $game->id)); ?>" class="btn btn-outline-dark">✏</a>
                            <a href="<?php echo e(route('games.destroy', $game->id)); ?>" class="btn btn-outline-dark">❌</a>
                            
                        </form>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Facum\Desktop\Facum\davinci\4to cuatrimestre\Portales y comercio electronico\gindie\resources\views/games.blade.php ENDPATH**/ ?>