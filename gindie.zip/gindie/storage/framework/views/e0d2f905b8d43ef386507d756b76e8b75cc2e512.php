<form action="/register" method="post">
    <?php echo csrf_field(); ?>

    <div id="name">
         <label for="name">Nombre</label>
         <input type="text" name="name">
    </div>

    <div id="email">
         <label for="email">Mail</label>
         <input type="email"  name="email">
    </div>

    <div id="password">
         <label for="password">Contraseña</label>
         <input type="password"  name="password">
    </div>

    <button>Continuar</button>
</form><?php /**PATH C:\Users\Alumno\Desktop\gindie\resources\views/register.blade.php ENDPATH**/ ?>