

<?php $__env->startSection('content'); ?>
    <section class="mt-5">
        <h1>Lista de juegos:</h1>
        <div class="row row-cols-1 row-cols-md-4 g-4 mx-auto">
            <?php $__currentLoopData = $juegos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juego): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card" style="width: 18rem;">
                        <img src="<?php echo e(Storage::url('app' . $juego->imagen)); ?>" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($juego->name); ?></h5>
                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="card-text"><?php echo e($categoria-> categoria); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <p class="card-text"><?php echo e($juego->plataforma); ?></p>
                            <p class="card-text"><?php echo e($juego->tamanio); ?> GB</p>
                            <a href="#" class="btn btn-outline-dark">📥</a>
                            <?php if(Auth::check() && Auth::user()->role === 'admin'): ?>
                            <a href="<?php echo e(route('juegos.edit', $juego->id)); ?>" class="btn btn-outline-dark">✏</a>
                            <a href="<?php echo e(route('juegos.destroy', $juego->id)); ?>" class="btn btn-outline-dark">❌</a>
                            
                        </form>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alumno\Desktop\gindie\resources\views/juegos.blade.php ENDPATH**/ ?>