

<?php $__env->startSection('content'); ?>

<form action="/registerAdmin" method="post" class="mt">
    <?php echo csrf_field(); ?>

    <div id="name">
         <label for="name">Nombre</label>
         <input type="text" name="name">
    </div>

    <div id="email">
         <label for="email">Mail</label>
         <input type="email"  name="email">
    </div>

    <div id="password">
         <label for="password">Contraseña</label>
         <input type="password"  name="password">
    </div>

    <button>Continuar</button>
</form>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alumno\Desktop\gindie\resources\views/registerAdmin.blade.php ENDPATH**/ ?>