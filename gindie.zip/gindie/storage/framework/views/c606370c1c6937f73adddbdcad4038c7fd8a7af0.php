

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('juegos.store')); ?>" method="post" class="mt" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field($method); ?>     

    <div id="name">
        <label for="name">Nombre</label>
        <input type="text" name="name" value="">
    
    </div>
    <div id="categoriasDiv">
    <label for="categorias">Categorias</label>
    <select name="categorias" id="categorias">
    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($categoria->name); ?>"><?php echo e($categoria->name); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    </div>

    <div id="plataforma">
        <label for="plataforma">Plataforma</label>
        <input type="text" name="plataforma">
    </div>

    <div id="tamanio">
        <label for="tamanio">Tamaño</label>
        <input type="number" name="tamanio">
    </div>

    <div>
        <label for="imagen">Foto</label>
        <input type="file" name="imagen" accept="image/jpg,image/jpeg,image/png">
    </div>
    <button>Cargar Juego</button>
</form>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alumno\Desktop\gindie\resources\views/cargarJuego.blade.php ENDPATH**/ ?>