
   
   
   <?php $__env->startSection('content'); ?>

  <!-- ======= Hero Section ======= -->
     
    <?php echo $__env->make('carrusel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
  <!-- End Hero -->

  <main id="main">

    <!-- ======= My & Family Section ======= -->
    
    <?php echo $__env->make('gindie', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!-- End My & Family Section -->

    <!-- ======= Features Section ======= -->
    <!-- End Features Section -->
    
    <!-- End Recent Photos Section -->

  </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Facum\Desktop\Facum\davinci\4to cuatrimestre\Portales y comercio electronico\gindie\resources\views/index.blade.php ENDPATH**/ ?>