

<section class="mt-5">
<div class="card text-center">
  <div class="card-header">
    Categorias
  </div>
  <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="card-body">
    <h5 class="card-title"><?php echo e($categoria->name); ?></h5>
    
  </div>
  <div class="card-footer text-body-secondary">
    <?php echo e($categoria->created_at); ?>

  </div>
  <hr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
</div>

</section>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alumno\Desktop\gindie\resources\views/categorias.blade.php ENDPATH**/ ?>