<?php
$slides = [
    'img/carrusel/shovel.jpg',
    'img/carrusel/stardew.png',
    'img/carrusel/meat.jpg',
]
?>

<section id="hero">
    <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel" data-bs-interval="3000"> 


        <div class="carousel-inner" role="listbox">

            <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            if($loop->first)
            <?php echo $__env->make('carrousel-item', [
              'isActive' => $loop->first,
              'url' => $slide
              ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>
</section>
<?php /**PATH C:\Users\Facum\Desktop\gindie\resources\views/carrusel.blade.php ENDPATH**/ ?>