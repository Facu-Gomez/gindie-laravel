<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
        <p><?php echo e($message -> id); ?></p>
        <p><?php echo e($message -> email); ?></p>
        <p>Recibido <?php echo e($message -> created_at); ?></p>
    </div>
    <a href="/messages/<?php echo e($message -> id); ?>/edit"> editar </a>
    

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\Alumno\Desktop\proyecto-base\resources\views/messages.blade.php ENDPATH**/ ?>