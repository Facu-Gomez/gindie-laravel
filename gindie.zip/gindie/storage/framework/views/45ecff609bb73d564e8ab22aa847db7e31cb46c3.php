

<?php $__env->startSection('content'); ?>
<section>
    <h1 class="mt-5 text-center">Estadísticas</h1>
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fa-solid fa-gamepad" style="color: #8536ba; font-size: 2rem;"></i>
                        <h5 class="card-title mt-3">Cantidad de Juegos</h5>
                        <p class="card-text"><?php echo e($gamesCount); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fa-solid fa-newspaper" style="color: #8536ba; font-size: 2rem;"></i>
                        <h5 class="card-title mt-3">Cantidad de Noticias</h5>
                        <p class="card-text"><?php echo e($newsCount); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fa-solid fa-user" style="color: #8536ba; font-size: 2rem;"></i>
                        <h5 class="card-title mt-3">Cantidad de Usuarios</h5>
                        <p class="card-text"><?php echo e($usersCount); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Facum\Desktop\Facum\davinci\4to cuatrimestre\Portales y comercio electronico\gindie\resources\views/Admin/estadistics.blade.php ENDPATH**/ ?>