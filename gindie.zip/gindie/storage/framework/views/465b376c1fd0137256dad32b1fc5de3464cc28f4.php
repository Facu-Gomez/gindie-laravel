
<div class="mt">
        <h1 id="exitoso" class="text-center">Su carga ha sido exitosa!</h1>
        <h2 id="volver" class="text-center"><a href="/">Volver al inicio</a></h2>
    </div>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Facum\Desktop\gindie\resources\views/exito.blade.php ENDPATH**/ ?>