<div class="carousel-item <?php echo e($isActive ? 'active' : ''); ?>"
 style="background-image: url(<?php echo e($url); ?>)">
</div><?php /**PATH C:\Users\Alumno\Desktop\proyecto-base\resources\views/carrousel-item.blade.php ENDPATH**/ ?>