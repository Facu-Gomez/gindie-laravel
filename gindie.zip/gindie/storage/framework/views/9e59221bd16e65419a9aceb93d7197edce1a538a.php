

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-body text-center"> <!-- Alineado al centro -->
                        <h1 class="card-title mb-4">Perfil de Usuario</h1>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">
                                <strong>Nombre:</strong> <?php echo e($user->name); ?>

                            </li>
                            <li class="list-group-item">
                                <strong>Email:</strong> <?php echo e($user->email); ?>

                            </li>
                        </ul>
                        <a href="<?php echo e(route('admin.user.edit', ['user' => $user->id])); ?>" class="btn btn-light mt-4"><i class="fa-solid fa-pencil" style="color: #8536ba; font-size: 1rem;"></i> Editar Perfil</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Facum\Desktop\Facum\davinci\4to cuatrimestre\Portales y comercio electronico\gindie\resources\views/profile.blade.php ENDPATH**/ ?>