

<?php $__env->startSection('content'); ?>
    <section class="mt-5">
        <h1>Lista de Usuarios:</h1>
        <div class="row row-cols-1 row-cols-md-4 g-4 mx-auto">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card" style="width: 18rem;">

                        <div class="card-body">
                            <h5 class="card-title">Nombre: <?php echo e($user->name); ?></h5>
                            <p class="card-text">Mail: <?php echo e($user->email); ?></p>
                            <p class="card-text">Rol: <?php echo e($user->role); ?></p>

                        </form>
                   
                        </div>
                    </div>
                    
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Facum\Desktop\Facum\davinci\4to cuatrimestre\Portales y comercio electronico\gindie\resources\views/Admin/users.blade.php ENDPATH**/ ?>