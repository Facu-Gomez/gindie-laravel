

<section class="mt-5">
<div class="card text-center">
  <div class="card-header">
    Novedades!
  </div>
  <?php $__currentLoopData = $miniNovedades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $miniNovedad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="card-body">
    <h5 class="card-title"><?php echo e($miniNovedad->titulo); ?></h5>
    
    <p class="card-text"><?php echo e($miniNovedad->descripcion); ?></p>
  </div>
  <div class="card-footer text-body-secondary">
    <?php echo e($miniNovedad->created_at); ?>

  </div>
  <hr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
</div>

</section>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Facum\Desktop\gindie\resources\views//novedades.blade.php ENDPATH**/ ?>