
<?php
$slides = [
  'beaches' => [
    'img/gallery/beach-1.jpg',
    'img/gallery/beach-2.jpg',
    'img/gallery/beach-3.jpg'
    ],
  'homes' => [
    'img/gallery/home-1.jpg',
    'img/gallery/home-2.jpg',
    'img/gallery/home-3.jpg'
    ],
  'vacations' => [
    'img/gallery/vacation-1.jpg',
    'img/gallery/vacation-2.jpg',
    'img/gallery/vacation-3.jpg'
    ]
]

?>
<section id="gallery" class="gallery">
      <div class="container">

        <div class="row">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="gallery-flters">
              <li data-filter="*" class="filter-active">All</li>
              <li data-filter=".filter-home">Home</li>
              <li data-filter=".filter-beach">Beach</li>
              <li data-filter=".filter-vacation">Vacation</li>
            </ul>
          </div>
        </div>

        <div class="row gallery-container" style="position: relative; height: 1505.88px;">

        <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('gallery-item', [
              'url' => $url
              ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

      </div>
    </section>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alumno\Desktop\proyecto-base\resources\views/gallery.blade.php ENDPATH**/ ?>