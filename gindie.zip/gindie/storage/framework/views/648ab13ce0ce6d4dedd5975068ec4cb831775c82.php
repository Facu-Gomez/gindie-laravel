<div class="carousel-item <?php echo e($isActive ? 'active' : ''); ?>"
 style="background-image: url(<?php echo e($url); ?>)">
</div><?php /**PATH C:\Users\Facum\Desktop\gindie\resources\views/carrousel-item.blade.php ENDPATH**/ ?>