<section id="about" class="about">
      <div class="container">

        <div class="section-title">
          <h2>¿Que es GINDIE?</h2>
          <p>En primer lugar, nuestra plataforma está dedicada exclusivamente a juegos independientes, lo que significa que cada título que encontrarás en Gindie es una joya única, creada con pasión y creatividad por desarrolladores independientes de todo el mundo. Creemos en dar visibilidad a estos talentosos creadores y en ofrecerles un espacio donde sus obras puedan brillar.</p>
        </div>

        <div class="row content">
          <div class="col-lg-6">
            <img src="<?php echo e(asset ('img/logo/GINDIE.png')); ?>" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
            <p>
            En Gindie, encontrarás una amplia selección de juegos indies en diferentes géneros, desde aventuras emocionantes hasta rompecabezas desafiantes y simuladores cautivadores. 
            </p>
            <p>
            En Gindie, la satisfacción del jugador es nuestra máxima prioridad. Nuestra plataforma es fácil de usar, con descargas rápidas y seguras para que puedas sumergirte rápidamente en la acción. También ofrecemos precios competitivos y promociones frecuentes para que puedas disfrutar de más juegos sin romper tu bolsillo.
            </p>
          </div>
        </div>
      </div>
    </section>


    <section id="recent">
    <h3>Juegos destacados</h3>
        <div id="juego1">
          <div class="card" style="width: 18rem;">
            <img src="<?php echo e(asset ('img/games/cuphead.png')); ?>" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Cuphead</h5>
              <p class="card-text">Cuphead es un videojuego perteneciente al género de corre y dispara, publicado por la empresa canadiense StudioMDHR.</p>
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
        </div>

          <div id="juego2">
            <div class="card " style="width: 18rem;">
              <img src="<?php echo e(asset ('img/games/hollow.png')); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Hollow Knight</h5>
                <p class="card-text">Hollow Knight es un videojuego perteneciente al género metroidvania desarrollado y publicado por Team Cherry.</p>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
        </div>

          <div  id="juego3">
            <div class="card " style="width: 18rem;">
              <img src="<?php echo e(asset ('img/games/hotline.png')); ?>" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Hotline Miami</h5>
              <p class="card-text">Hotline Miami es un videojuego de acción independiente estilo shoot 'em up desarrollado por Dennaton Games</p>
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
          </div>

          <div id="juego4" >
            <div class="card " style="width: 18rem;">
              <img src="<?php echo e(asset ('img/games/rogue.png')); ?>" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Rogue Legacy: 2</h5>
              <p class="card-text">Rogue Legacy 2 es un juego de plataformas desarrollado y publicado por el estudio indie Cellar Door Games.</p>
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
          </div>

          <div id="juego5" >
            <div class="card " style="width: 18rem;">
              <img src="<?php echo e(asset ('img/games/stray.png')); ?>" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Stray</h5>
              <p class="card-text">Stray es un juego de aventuras desarrollado por BlueTwelve Studio y publicado por Annapurna Interactive.</p>
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
          </div>
          
          <div id="juego6" >
            <div class="card " style="width: 18rem;">
              <img src="<?php echo e(asset ('img/games/olli.png')); ?>" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">OlliOlli World</h5>
              <p class="card-text">OlliOlli World es un videojuego de skate desarrollado por Roll7 y publicado por Private Division.</p>
              <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
          </div>
</section>
</section><?php /**PATH C:\Users\Alumno\Desktop\gindie\resources\views/myFamily.blade.php ENDPATH**/ ?>