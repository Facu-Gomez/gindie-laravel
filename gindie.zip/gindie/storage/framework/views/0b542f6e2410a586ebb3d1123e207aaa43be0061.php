
<header id="header" class="fixed-top">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="/">GINDIE</a></h1>

      <nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="/">Home</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link " href="/juegos">Juegos</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " href="/novedades">Novedades</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/categorias">Categorias</a>
        </li>
        <?php if(Auth::check()): ?>
        <li class="nav-item">
          <a class="nav-link" href="/library">Biblioteca</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/login">Cerrar sesion</a>
        </li>
        <?php endif; ?>
        <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(Auth::user()->name); ?>

                        </a>
                        

                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <?php if(Auth::check() && Auth::user()->role === 'admin'): ?>
                   
                            <a class="dropdown-item" href="<?php echo e(route('juegos.create')); ?>">Registrar un Juego</a>
                   
                            <a class="dropdown-item" href="/cargarNovedades"> Registrar una Novedad</a>
        
                            <a class="dropdown-item" href="<?php echo e(route('categorias.create')); ?>"> Registrar una Categoria</a>
                    
                        <?php endif; ?>
                           
                        </div>
                    </li>

        <?php if (! (Auth::check())): ?>
        <li class="nav-item">
          <a class="nav-link" href="/login">Iniciar sesion</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/register">Registrarse</a>
        </li>
      <?php endif; ?>
     
      </ul>

    </div>
  </div>
</nav>

    </div>
  </header>
<?php /**PATH C:\Users\Alumno\Desktop\gindie\resources\views/navegacion.blade.php ENDPATH**/ ?>