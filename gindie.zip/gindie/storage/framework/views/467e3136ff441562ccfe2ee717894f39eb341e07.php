<?php
$biblioteca = session('biblioteca', []);
?>

<section class="mt-5">
    <h1>Mi Biblioteca:</h1>
    <?php $__currentLoopData = $biblioteca; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juegoId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $juego = App\Models\Juego::find($juegoId);
        ?>

        <div class="card" style="width: 18rem;">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($juego->name); ?></h5>
                <p class="card-text"><?php echo e($juego->categoria); ?></p>
                <p class="card-text"><?php echo e($juego->plataforma); ?></p>
                <p class="card-text"><?php echo e($juego->tamanio); ?> GB</p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<?php /**PATH C:\Users\Facum\Desktop\Facum\davinci\4to cuatrimestre\Portales y comercio electronico\gindie\resources\views/library.blade.php ENDPATH**/ ?>