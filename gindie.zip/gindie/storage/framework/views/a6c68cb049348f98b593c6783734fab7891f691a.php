
<?php $__env->startSection('content'); ?>

<div class="container my-5">
<div class="row ">
    <div class="col my-5">

<div class="container w-50">

<form action="/contact" method="post">

    <?php echo csrf_field(); ?>
    
    <div>
        <label for="" class="form-label">Email</label>
        <input  class="form-control" type="email" name="email" value="<?php echo e(old('email, email')); ?>">
        <p><?php echo e($errors -> first('email')); ?>  </p>
    </div>
    <div>
        <label for="" class="form-label">Nombre</label>
        <input class="form-control" type="text" name="name" value="<?php echo e(old('name, $message -> name')); ?>">
        <p><?php echo e($errors -> first('name')); ?>  </p>
    </div>
    <div>
        <label for="" class="form-label">Motivo</label>
        <p><?php echo e($errors -> first('motivo')); ?>  </p>

        <select name="motivo" id="" class="form-select form-select-lg mb-3">
            <option value="1" <?php if(old('motivo') == 1): echo 'selected'; endif; ?>>Viajes</option>
            <option value="2" <?php if(old('motivo') == 2): echo 'selected'; endif; ?>>Reuniones</option>
            <option value="3" <?php if(old('motivo') == 3): echo 'selected'; endif; ?>>Otros</option>
        </select>
    </div>
    <div>
        <label for="" class="form-label">Mensaje</label>
        <p><?php echo e($errors -> first('message')); ?>  </p>

        <input type="textarea" class="form-control" cols="30" row="10" name="message" value="<?php echo e(old('message')); ?>">
    </div>
    <div class="mt-3 text-center ">
        <button class="btn btn-primary">Enviar</button>
    </div>

</form>
</div>


</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<style>
    form p{
        color:red;
    }
</style>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alumno\Desktop\proyecto-base\resources\views/contact.blade.php ENDPATH**/ ?>