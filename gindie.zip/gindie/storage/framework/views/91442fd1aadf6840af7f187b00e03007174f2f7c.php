<div class="col-lg-4 col-md-6 gallery-item filter-home" style="position: absolute; left: 0px; top: 0px;">
            <div class="gallery-wrap">
              <img src="<?php echo e($url); ?>" class="img-fluid" alt="">
              <div class="gallery-info">
                <h4>Home 1</h4>
                <p>Home</p>
                <div class="gallery-links">
                  <a href="<?php echo e($url); ?>" class="glightbox" title="Home 1"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div><?php /**PATH C:\Users\Alumno\Desktop\proyecto-base\resources\views/gallery-item.blade.php ENDPATH**/ ?>