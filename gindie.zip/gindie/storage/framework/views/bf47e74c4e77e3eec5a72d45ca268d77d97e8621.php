

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('games.update', $game)); ?>" method="post" class="mt" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field($method); ?>     

    <div id="name">
        <label for="name">Nombre</label>
        <input type="text" name="name" value="<?php echo e($game->name); ?>">
    
    </div>
    <div id="categoriasDiv">
    <label for="categories">Categorias</label>
    <select name="category_id" id="categories">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    </div>

    <div id="plataform">
        <label for="plataform">Plataforma</label>
        <input type="text" name="plataform" value="<?php echo e($game->plataform); ?>">
    </div>

    <div id="size">
        <label for="size">Tamaño</label>
        <input type="number" name="size" value="<?php echo e($game->size); ?>">
    </div>

    <div>
        <label for="image">Foto</label>
        <input type="file" name="image" accept="image/jpg,image/jpeg,image/png">
    </div>
    <button>Actualizar Juego</button>
</form>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Facum\Desktop\Facum\davinci\4to cuatrimestre\Portales y comercio electronico\gindie\resources\views/editGame.blade.php ENDPATH**/ ?>