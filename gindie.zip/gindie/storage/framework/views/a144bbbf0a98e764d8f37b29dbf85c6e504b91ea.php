

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('categorias.store')); ?>" method="post" class="mt" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div id="name">
        <label for="name">Nombre</label>
        <input type="text" name="name" value="">
    </div>

    <button>Cargar Categoria</button>
</form>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alumno\Desktop\gindie\resources\views/cargarCategorias.blade.php ENDPATH**/ ?>