

<form action="/cargarNovedades" method="post" class="mt">
<?php echo csrf_field(); ?>

    <div id="titulo">
         <label for="titulo">Titulo</label>
         <input type="titulo" name="titulo">
    </div>

    <div id="descripcion">
         <label for="descripcion">Cuerpo de texto</label>
         <textarea name="descripcion" id="descripcion" cols="30" rows="10"></textarea>
    </div>


    <button>Cargar Novedad</button>
</form>
<a href="/">Volver</a>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Facum\Desktop\gindie\resources\views/cargarNovedades.blade.php ENDPATH**/ ?>