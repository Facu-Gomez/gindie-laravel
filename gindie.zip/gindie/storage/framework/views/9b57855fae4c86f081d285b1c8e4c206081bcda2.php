
<header id="header" class="fixed-top">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="/">GINDIE</a></h1>

      <nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="/">Home</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link " href="/games">Juegos</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " href="/news">Novedades</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/categories">Categorias</a>
        </li>
        <?php if(Auth::check()): ?>
        <li class="nav-item">
          <a class="nav-link" href="/library">Biblioteca</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/login">Cerrar sesion</a>
        </li>
        <?php endif; ?>
        <?php if(Auth::check()): ?>
        <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(Auth::user()->name); ?>

                        </a>
                        

                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        

                        <a class="dropdown-item" href="<?php echo e(route('admin.user.show', ['user' => auth()->user()])); ?>">Perfil</a>

                        <?php if(Auth::check() && Auth::user()->role === 'admin'): ?>
                            <a class="dropdown-item" href="<?php echo e(route('games.create')); ?>">Registrar un Juego</a>
                   
                            <a class="dropdown-item" href="<?php echo e(route('news.create')); ?>"> Registrar una Novedad</a>
        
                            <a class="dropdown-item" href="<?php echo e(route('categories.create')); ?>"> Registrar una Categoria</a>

                            <a class="dropdown-item" href="<?php echo e(route('users.index')); ?>">Todos los usuarios</a>

                            <a class="dropdown-item" href="<?php echo e(route('estadistics.index')); ?>">Estadisticas</a>
                    
                        <?php endif; ?>

                           
                        </div>
                    </li>
        <?php endif; ?>
        <?php if (! (Auth::check())): ?>
        <li class="nav-item">
          <a class="nav-link" href="/login">Iniciar sesion</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('users.create')); ?>">Registrarse</a>
        </li>
      <?php endif; ?>
     
      </ul>

    </div>
  </div>
</nav>

    </div>

    <?php if(session('status')): ?>
      alert(<?php echo e(session); ?>)
    <?php endif; ?>
  </header>
<?php /**PATH C:\Users\Facum\Desktop\Facum\davinci\4to cuatrimestre\Portales y comercio electronico\gindie\resources\views/navegation.blade.php ENDPATH**/ ?>