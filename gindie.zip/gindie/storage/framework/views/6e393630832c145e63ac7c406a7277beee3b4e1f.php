

<?php $__env->startSection('content'); ?>
    <section class="mt-5">
        <h1>Lista de juegos:</h1>
        <div class="row row-cols-1 row-cols-md-4 g-4 mx-auto">
            <?php $__currentLoopData = $jueguitos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jueguito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card" style="width: 18rem;">
                        <img src="<?php echo e(Storage::url('app' . $jueguito->imagen)); ?>" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($jueguito->name); ?></h5>
                            <p class="card-text"><?php echo e($jueguito->categoria); ?></p>
                            <p class="card-text"><?php echo e($jueguito->plataforma); ?></p>
                            <p class="card-text"><?php echo e($jueguito->tamanio); ?> GB</p>
                            <a href="#" class="btn btn-outline-dark">📥</a>
                            <?php if(Auth::check() && Auth::user()->role === 'admin'): ?>
                            <a href="/juegos/<?php echo e($jueguito->id); ?>/edit" class="btn btn-outline-dark">✏</a>
                            <form action="/juegos/<?php echo e($jueguito->id); ?>" method="POST" class="eliminar">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-outline-dark">❌</button>
                        </form>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Facum\Desktop\gindie\resources\views//juegos.blade.php ENDPATH**/ ?>