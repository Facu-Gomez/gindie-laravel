<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Games;
use App\Models\News;
use App\Http\Controllers\Admin\GameController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\PlayerController;
use App\Http\Controllers\Admin\NewsController;
use App\Http\Controllers\Admin\CategoriesController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\LibraryController;
use App\Http\Controllers\LoginController;
use Illuminate\Support\Facades\Hash;
use App\Http\Middleware\CheckLogin;



Route::resource('registerAdmin', AdminController::class);
Route::resource('users', PlayerController::class);
Route::resource('login', LoginController::class);
Route::resource('categories', CategoriesController::class)->middleware('checkLogin');
Route::resource('games', GameController::class);
Route::resource('news', NewsController::class)->middleware('checkLogin');
Route::resource('library', LibraryController::class)->middleware('checkLogin');
Route::resource('estadistics', DashboardController::class);

Route::get('/admin/user/{user}', [AdminController::class, 'show'])->name('admin.user.show');
Route::get('/admin/user/{user}/edit', [AdminController::class, 'edit'])->name('admin.user.edit');
Route::put('/admin/user/{user}', [AdminController::class, 'update'])->name('admin.user.update');

Route::get('/', function () {
    return view('index');
});

