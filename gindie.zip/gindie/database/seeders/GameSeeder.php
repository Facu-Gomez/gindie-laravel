<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class GameSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\Models\Games::factory(10)->create();
       /* $data = [
            [
                'id' => 1,
                'name' => 'Cuphead',
                'category_id' => 1,
                'plataform' => 'Plataforma 1',
                'size' => 10
            ],
            [
                'id' => 2,
                'name' => 'Plants VS Zombies',
                'category_id' => 2,
                'plataform' => 'PC',
                'size' => 1
            ],
            [
                'id' => 3,
                'name' => 'DOTA 2',
                'category_id' => 3,
                'plataform' => 'PC',
                'size' => 15
            ]
        ];
        DB::table('games')->insert($data); */
    }
}
