<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data = [
            [
                'id' => 1,
                'name' => 'Pelea'
            ],
            [
                'id' => 2,
                'name' => 'Casual'
            ],
            [
                'id' => 3,
                'name' => 'MOBA'
            ],
            [
                'id' => 4,
                'name' => 'Shooter'
            ],
            [
                'id' => 5,
                'name' => 'Deporte'
            ]
            ];
            DB::table('categories')->insert($data); 
    }
}
